class Problems {
  void callProblem() {
    print("COVID-19");
  }
}
