class Problem {
  void showProblem() {
    print('ปัญหา COVID-19');
  }
}
