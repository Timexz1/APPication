void main() {
  print("Hello World");
  print("Anutchai");
  print("Chutipascharoen");
  print("mmmmm");
}
