package com.example.mobileappweek1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
