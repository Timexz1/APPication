import 'package:flutter/material.dart';

const pColor = Color(0xFF6DA892);

const sColor = Color(0xFFF89A9A);

const tColor = Color(0xFFF89A22);

const boxSize = 20.0;
